namespace FinalProject {
    // ReSharper disable once RedundantExtendsListEntry
    public partial class ManageMember : ContentPage {
        public ManageMember() => InitializeComponent();
    }
}
