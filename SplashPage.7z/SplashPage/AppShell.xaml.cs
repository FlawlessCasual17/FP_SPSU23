namespace SplashPage {
    // ReSharper disable once RedundantExtendsListEntry
    public partial class AppShell : Shell {
        public AppShell() { InitializeComponent(); }
    }
}
